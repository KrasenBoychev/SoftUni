import { html } from "@lit-html/lit-html.js";
import { ingredientItemTemplate, preparationStepTemplate } from "./partials.js";


/**
 * 
 * @param {import("@src/data/recipes").RecipeModel} item 
 * @returns {Object}
 */
const detailsTemplate = (item) => html`
<section>
        <article>
            <h2>${item.name}</h2>
            <div class="band">
                <div class="thumb">
                    <img src="../assets/${item.img}.jpg">
                </div>
                <div class="ingredients">
                    <h3>Ingredients:</h3>
                    <ul>
                        ${item.ingredients.map(x => ingredientItemTemplate(x))}
                    </ul>
                </div>
            </div>
            <div class="description">
                <h3>Preparation:</h3>
               ${item.steps.map(x => preparationStepTemplate(x))}
            </div>
            <div>
                <a href="/edit/${item.objectId}">Edit</a>
                <a href="delete">Delete</a>
            </div>
        </article>
</section>
`;

export function showDetails(ctx) { 
    ctx.render(detailsTemplate(ctx.data));
}

