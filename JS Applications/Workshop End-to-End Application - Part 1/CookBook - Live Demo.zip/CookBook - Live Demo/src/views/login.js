import { html } from "@lit-html/lit-html.js";
import { goTo } from "@src/app.js";
import { login } from "@src/data/users.js";
import { createSubmitHandler } from "@src/util.js";

const loginTemplate = (handler) => html`
    <section id="login">
            <article>
                <h2>Login</h2>
                <form @submit=${handler}>
                    <label>E-mail: <input type="text" name="email"></label>
                    <label>Password: <input type="password" name="password"></label>
                    <input type="submit" value="Login">
                </form>
            </article>
        </section>
`;

/**
 * @param {import("@src/types").PageContext} ctx 
 */
export function showLogin(ctx) {
    ctx.render(loginTemplate(createSubmitHandler(onLogin)));
}

/**
 * @param {import("@src/types").UserData} data
 * @param {*} form 
 */
function onLogin(data, form) {
    const { email, password } = data;

    if (!email || !password) {
        return alert("Login error");
    }

    login(email, password);
    form.reset();
    goTo("/");
}